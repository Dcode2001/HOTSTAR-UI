class Model {
  List<String> images = [
    "myimages/img.png",
    "myimages/img_1.png",
    "myimages/img_2.png",
    "myimages/img_3.png",
    "myimages/img_4.png",
    "myimages/img_5.png",
    "myimages/img_6.png",
    "myimages/img_7.png",
    "myimages/img_8.png",
    "myimages/img_9.png",
    "myimages/img_10.png",
    "myimages/img_11.png",
    "myimages/img_12.png",
    "myimages/img_13.png",
    "myimages/img_14.png",
    "myimages/img_15.png",

  ];
}
