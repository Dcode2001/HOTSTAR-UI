import 'package:flutter/material.dart';
import 'package:hotstar/firstpage.dart';
import 'package:hotstar/secondpage.dart';

void main()
{
      runApp(MaterialApp(home: firstpage(),));
}