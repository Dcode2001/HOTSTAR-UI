import 'package:flutter/material.dart';
import 'package:hotstar/Model.dart';

class firstpage extends StatefulWidget {
  const firstpage({Key? key}) : super(key: key);

  @override
  State<firstpage> createState() => _firstpageState();
}

class _firstpageState extends State<firstpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Column(
              children: [
                Container(
                  width: double.infinity,
                  color: Colors.black26,
                  alignment: Alignment.bottomLeft,
                   padding: EdgeInsets.all(5),
                  child: Text("Latest & Trending",style: TextStyle(fontSize: 20),),
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(5),
                  alignment: Alignment.center,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          
                        },
                        child: Container(
                          height: 100,
                          width: 100,
                          margin: EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          child: Image.asset(Model().images[index],fit: BoxFit.fill,),
                        ),
                      );
                    },itemCount: Model().images.length,
                  ),
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(5),
                  alignment: Alignment.center,
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(5),
                  alignment: Alignment.center,
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(5),
                  alignment: Alignment.center,
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(10),
                  alignment: Alignment.center,
                ),
                Container(
                  height: 150,
                  color: Colors.black26,
                  margin: EdgeInsets.all(10),
                  alignment: Alignment.center,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
